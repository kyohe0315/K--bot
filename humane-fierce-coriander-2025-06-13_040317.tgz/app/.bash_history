@k-bot
console
node -v
npm -v
nvm install 20
node install
npm install
node -v
npm install node
node -v
node-v
node -v
node -v
node -v
node -v
npm install discord.js@latest
rm -rf node_modules
pnpm install
npm install axios
npm install ical
npm install luxon
npm install node-cron
npm install cheerio
npm install node-fetch
npm install undici
nvm install node
node -v
npm install undici@4.0.0
nvm install --lts
nvm install --its
npm install undici
npm install undici@latest
npm install node-fatch
npm install node-fetch@2
npm install axios cheerio
npm install axios
npm install axios
npm install ical
npm install node-cron
postMonthlyEvents();
